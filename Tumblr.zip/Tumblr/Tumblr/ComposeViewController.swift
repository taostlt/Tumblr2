//
//  ComposeViewController.swift
//  Tumblr
//
//  Created by Alex on 11/5/16.
//  Copyright © 2016 Alex. All rights reserved.
//

import UIKit

class ComposeViewController: UIViewController {
    
    @IBOutlet weak var chatView: UIImageView!
    
    var chatViewOriginalPosition : CGPoint!
    
    override func viewWillAppear(_ animated: Bool) {
        
        chatView.center.y = chatViewOriginalPosition.y-10
    }
 

    override func viewDidLoad() {
        super.viewDidLoad()
        
        chatViewOriginalPosition = chatView.center

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        UIView.animate(withDuration:0.4, delay: 0.0,
                       options: [.autoreverse, .repeat],
                       animations: { () -> Void in
                        self.chatView.transform = CGAffineTransform(scaleX: 1.5, y: 1.5)
            }, completion: nil)
    }
    
    @IBAction func dismissView(_ sender: AnyObject) {
        dismiss(animated: true, completion: nil)
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
